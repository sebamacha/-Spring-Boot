package com.todocodeacademy.parametrosGetmapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParametrosGetmappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
