package com.todocodeacademy.parametrosGetmapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParametrosGetmappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParametrosGetmappingApplication.class, args);
	}

}
