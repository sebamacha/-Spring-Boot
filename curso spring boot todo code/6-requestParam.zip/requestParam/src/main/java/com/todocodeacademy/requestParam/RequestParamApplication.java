package com.todocodeacademy.requestParam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequestParamApplication {

	public static void main(String[] args) {
		SpringApplication.run(RequestParamApplication.class, args);
	}

}
