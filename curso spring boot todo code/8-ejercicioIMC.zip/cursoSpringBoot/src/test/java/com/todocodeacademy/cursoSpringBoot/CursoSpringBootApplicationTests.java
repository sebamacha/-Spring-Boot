package com.todocodeacademy.cursoSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
